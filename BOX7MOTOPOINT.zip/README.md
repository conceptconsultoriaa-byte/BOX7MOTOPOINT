# BOX7 Moto Point
Troque os links Hotmart e WhatsApp em index.html.
Ative GitHub Pages em Settings>Pages.